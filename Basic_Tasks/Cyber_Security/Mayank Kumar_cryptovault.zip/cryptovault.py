import argparse
import hashlib

# Standard English letter frequencies used by the cracker to find the right shift
english_freq = {
    'a': 8.2, 'b': 1.5, 'c': 2.8, 'd': 4.3, 'e': 13.0, 'f': 2.2,
    'g': 2.0, 'h': 6.1, 'i': 7.0, 'j': 0.15, 'k': 0.77, 'l': 4.0,
    'm': 2.4, 'n': 6.7, 'o': 7.5, 'p': 1.9, 'q': 0.09, 'r': 6.0,
    's': 6.3, 't': 9.1, 'u': 2.8, 'v': 0.98, 'w': 2.4, 'x': 0.15,
    'y': 2.0, 'z': 0.07
}

# Setting up the command-line interface so we can use terminal commands
parser = argparse.ArgumentParser()
subparsers = parser.add_subparsers(dest="command", required=True)

# Blueprint for the 'encrypt' command
encrypt = subparsers.add_parser("encrypt")
encrypt.add_argument("file", help="provide a file that has to be encrypted")
encrypt.add_argument("--shift", type=int, help="provide a valdi key", required=True)
encrypt.add_argument("--verify", action='store_true')  # Optional flag for Stage 2 hash verification

# Blueprint for the 'decrypt' command
decrypt = subparsers.add_parser("decrypt")
decrypt.add_argument("file", help="provide a file that has to be decrypted")
decrypt.add_argument("--shift", type=int, help="provide a valid key", required=True)
decrypt.add_argument("--verify", action='store_true')

# Blueprint for the 'crack' command
crack = subparsers.add_parser("crack")
crack.add_argument("text")

args = parser.parse_args()


# Helper functions to keep file reading and writing clean in the main block
def read_file(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        data = file.read()
    return data


def write_file(file_path, data):
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(data)


# Unified cipher function.
# Reversing the shift for decryption here saves me from writing the exact same math twice.
def caesar_cipher(in_data, shift, mode):
    if mode == "decrypt":
        shift = -shift
    out_data = ""
    for i in in_data:
        if i.isupper():
            out_data += chr(((ord(i) - 65 + shift) % 26) + 65)
        elif i.islower():
            out_data += chr(((ord(i) - 97 + shift) % 26) + 97)
        else:
            out_data += i  # Leave spaces and punctuation untouched
    return out_data


# Generates a SHA-256 hash fingerprint to check for tampering (Stage 2)
def compute_hash(text):
    hash_text = hashlib.sha256(text.encode('utf-8')).hexdigest()
    return hash_text


# Grabs just the top line of the file where the hash is stored
def read_hash(file_name):
    with open(file_name, 'r') as file:
        hash_line = file.readline().strip()
        return hash_line


# Skips the first line (the hash) and reads the rest of the ciphertext
def read_content(file_name):
    with open(file_name, 'r') as file:
        file.readline()
        content = file.read()
    return content


def main():
    if args.command == "encrypt":
        in_text = read_file(args.file)
        encrypt_text = caesar_cipher(in_text, args.shift, "encrypt")
        file_name = args.file
        new_file_name = file_name + ".enc"

        # If --verify is used, stick the hash on the very first line of the encrypted file
        if args.verify:
            hash_text = compute_hash(in_text)
            encrypt_text = f"{hash_text}\n{encrypt_text}"

        write_file(new_file_name, encrypt_text)

    elif args.command == "decrypt":
        new_file_name = args.file.replace(".enc", ".dec")

        if args.verify:
            # Extract ciphertext, decrypt it, and check if its new hash matches the stored hash
            content = read_content(args.file)
            decrypt_text = caesar_cipher(content, args.shift, "decrypt")

            if compute_hash(decrypt_text) == read_hash(args.file):
                write_file(new_file_name, decrypt_text)
                print("success")
            else:
                print("file has been corrupted")  # Warning fires if tampered
        else:
            # Standard Stage 1 decryption without hash checking
            content = read_file(args.file)
            decrypt_text = caesar_cipher(content, args.shift, "decrypt")
            write_file(new_file_name, decrypt_text)

    elif args.command == "crack":
        all_result = []

        # Test all 25 possible shifts
        for i in range(1, 26):
            chr_count = {}
            prc_count = {}
            error_difference = {}
            total_character = 0

            # Count the frequency of each letter in the current decryption attempt
            for k in caesar_cipher(args.text, i, "decrypt").lower():
                if k.isalpha():
                    if k not in chr_count:
                        chr_count[k] = 0
                    if k in chr_count:
                        chr_count[k] += 1
                    total_character += 1

            # Convert counts to percentages
            for a, b in chr_count.items():
                prc_count[a] = (b / total_character) * 100

            # Use Chi-squared logic to compare attempt frequencies against actual English frequencies
            for c, d in english_freq.items():
                if c in prc_count:
                    error_difference[c] = (abs(d - prc_count[c]) ** 2) / d
                if c not in prc_count:
                    error_difference[c] = english_freq[c]

            total_error_sum = sum(error_difference.values())

            # Package the error score and the shift key together as a tuple
            all_result.append((total_error_sum, i))

        # Sort the list of tuples by the error score (lowest error comes first)
        all_result.sort(key=lambda z: z[0])

        # Grab the shift keys from the top 3 best results and print them
        for x in range(3):
            best_shift = all_result[x][1]
            print(f"{x + 1}. {caesar_cipher(args.text, best_shift, 'decrypt')}")


main()
