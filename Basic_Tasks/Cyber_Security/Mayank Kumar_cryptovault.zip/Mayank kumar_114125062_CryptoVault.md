# CryptoVault - Spider R&D Club Write-up
**Name:** Mayank Kumar  
**Roll Number:** 114125062

## Stage 1: Caesar Lock

**What concept it implements:**
This stage uses the Caesar Cipher. It is a very basic secret code where you take every letter in your message and shift it forward by a certain number. For example, if the shift is 3, 'A' becomes 'D', 'B' becomes 'E', and so on.

**What it protects against:**
It only hides your message from regular people looking over your shoulder. It will not stop anyone who knows a little bit about coding or secret messages.

**Limitations & Why it's easily breakable:**
The biggest problem is that the English alphabet only has 26 letters. That means there are only 25 possible keys (shifts) you can use. A computer can test all 25 options in less than a second to find the readable English sentence. 

**What property of language makes frequency analysis work?**
In the English language, we don't use all letters equally. Letters like 'E', 'T', and 'A' are used everywhere, while 'Z' and 'X' are super rare. Because the Caesar cipher just replaces one letter with another, the pattern stays exactly the same. My cracking script simply finds the most common letter in the secret message and assumes it is probably an 'E'. This lets the script crack the code instantly without needing the key.

---

## Stage 2: Hash Guard

**What concept it implements:**
This stage mixes our secret code with a "Hash" (SHA-256). A hash is basically a unique, 64-character digital fingerprint for our text. When we use the `--verify` flag, the code creates this fingerprint and saves it at the top of our encrypted file.

**What it protects against:**
It protects our file from being messed with. If a hacker intercepts our file and changes even a single letter in the secret message, the decryption process will notice. The new fingerprint won't match the old one, and our code will print a warning.

**Limitations:**
Right now, our fingerprint is just sitting at the top of the file in plain text. If a hacker understands how our code works, they could delete our message, write their own fake message, create a new fingerprint for it, and save it. To fix this in the real world, we would need to lock the fingerprint with a secret password so the hacker couldn't fake it. 

*Important Note:* If you encrypt a file using `--verify`, you have to use `--verify` to decrypt it too! If you forget, the program will read the 64-character fingerprint as if it were part of the secret message, and the output will be totally ruined.

**Encryption gives confidentiality. Hashing gives integrity. Why do we need both?**
Encryption makes sure nobody can *read* our file (confidentiality). But encryption alone does not stop a hacker from *damaging* the file by randomly changing letters. If they change letters, we would just decrypt a broken, garbage message. By adding a hash, we get integrity. This means we have proof that the secret message we are reading is the exact same one that was originally sent to us, and nobody has messed with it.
